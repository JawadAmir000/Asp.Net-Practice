﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicDestroyers.Equipment.Weapons.Blunt
{
    public class Staff
    {
        private int damage;
        
        public Staff()
        {

        }

        public void Empower()
        {
            throw new NotImplementedException();
        }
    }
}
